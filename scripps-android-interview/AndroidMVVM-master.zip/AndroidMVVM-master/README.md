# AndroidMVVM

<p align="left">
  <img src="screenshots/screenshot1.png" width="200"/>
  <img src="screenshots/screenshot2.png" width="200"/>
  <img src="screenshots/screenshot3.png" width="200"/>
  <img src="screenshots/screenshot4.png" width="200"/>
</p>

Sample recipe app
